<?php
/**
 * Heading Shortcode
 */

wp_enqueue_style('cvca-style');

$css_class = $text = $text_style = $html = '';

$custom_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $atts['css'], ' ' ), 'CleverHeading', $atts );

if ( !empty( $atts['el_class'] ) ) {
    $css_class .= ' ' . $atts['el_class'];
}

if ( !empty( $custom_class ) ) {
    $css_class .= ' ' . $custom_class;
}

if ( $atts['font_custom'] == 'yes' ) {
    $text_style = 'style="font-size:'. ( is_numeric( trim( $atts['font_size'] ) ) ? trim( $atts['font_size'] ) . 'px' : trim( $atts['font_size'] ) ) . '; line-height:' . ( is_numeric( trim( $atts['line_height'] ) ) ? trim( $atts['line_height'] ) . 'px' : trim( $atts['line_height'] ) ) . '; font-weight: ' . ( is_numeric( trim( $atts['font_weight'] ) ) ? trim( $atts['font_weight'] ) : trim( $atts['font_weight'] ) ) . '; letter-spacing: '.( is_numeric( trim( $atts['letter_spacing'] ) ) ? trim( $atts['letter_spacing'] ) . 'px' : trim( $atts['letter_spacing'] ) ) . '; text-transform:' . esc_attr( $atts['text_transform'] ) . '; font-style: '. esc_attr( $atts['font_style'] ) .'; color:' . esc_attr( $atts['text_color'] ) . '"';
} else {
    $text_style = '';
}

if ( !empty( $atts['text'] ) ) {
    $html .= '<' . esc_attr( $atts['heading_tag'] ) . ' class="cvca-heading '. esc_attr( $atts['style'] ) . ' ' . esc_attr( $atts['text_align'] ) . ' ' . esc_attr( $css_class ) . ' " ' . $text_style . '>';
    $html .= '<span class="cvca-heading-text">' . wp_kses( $atts['text'], array( 'br' => array(), 'strong' => array() ) ) . '</span>';
    if ( $atts['style'] == 'number' ) {
    	 $html .= '<span class="cvca-heading-number">' . esc_attr( $atts['number'] ) . '</span>';
    }
    $html .= '</' . esc_attr( $atts['heading_tag'] ) . '>';
}

echo $html;
?>
