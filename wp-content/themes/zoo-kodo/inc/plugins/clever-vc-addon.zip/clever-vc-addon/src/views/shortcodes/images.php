<?php
/**
 * Banner Shortcode
 */

wp_enqueue_style('cvca-style');
$css_class = $zoo_start_link = $zoo_link_text = $zoo_end_link = $img = $gal_images = $thumbnail = $large_img_src = '';
$default_src = vc_asset_url( 'vc/no_image.png' );

$custom_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $atts['css'], ' ' ), 'CleverImages', $atts );

if ( !empty( $atts['style'] ) ) {
    $css_class .= ' ' . $atts['style'];
}

if ( !empty( $atts['el_class'] ) ) {
    $css_class .= ' ' . $atts['el_class'];
}

if ( !empty( $custom_class ) ) {
    $css_class .= ' ' . $custom_class;
}

$zoo_allow_tag = array(
    'a' => array(
        'class' => array(),
        'href' => array(),
        'target' => array(),
        'rel' => array(),
        'title' => array()
    ),
    'br' => array()
);

if ( !empty( $atts['link'] ) ) {
    $zoo_link = vc_build_link( $atts['link'] );

    if ( $zoo_link['url'] != '' ) {
        $zoo_start_link = '<a';
        $zoo_start_link .= ' class="zoo-media-link"';
        $zoo_start_link .= ' href="' . $zoo_link['url'] . '"';

        if ( $zoo_link['title'] != '' ) {
            $zoo_start_link .= ' title="' . $zoo_link['title'] . '"';
        }

        if ( $zoo_link['target'] != '' ) {
            $zoo_start_link .= ' target="' . $zoo_link['target'] . '"';
        }

         if ( $zoo_link['rel'] != '' ) {
            $zoo_start_link .= ' rel="' . $zoo_link['rel'] . '"';
        }

        $zoo_start_link .= '>';
    }

    $zoo_link_text = ( $zoo_link['title'] != '' ) ? $zoo_link['title'] : '';

    if ( $zoo_link['url'] != '' ) {
        $zoo_end_link = '</a>';
    }
}

switch ( $atts['source'] ) {
    case 'media_library':
        $atts['images'] = explode( ',', $atts['images'] );
        break;

    case 'external_link':
        $atts['images'] = vc_value_from_safe( $atts['custom_srcs'] );
        $atts['images'] = explode( ',', $atts['images'] );

        break;
}

foreach ( $atts['images'] as $i => $image ) {
    switch ( $atts['source'] ) {
        case 'media_library':
            if ( $image > 0 ) {
                $img = wpb_getImageBySize( array(
                    'attach_id' => $image,
                    'thumb_size' => $atts['img_size'],
                ) );
                $thumbnail = $img['thumbnail'];
                $large_img_src = $img['p_img_large'][0];
            } else {
                $large_img_src = $default_src;
                $thumbnail = '<img src="' . $default_src . '" />';
            }
            break;

        case 'external_link':
            $image = esc_attr( $image );
            $dimensions = vcExtractDimensions( $atts['external_img_size'] );
            $hwstring = $dimensions ? image_hwstring( $dimensions[0], $dimensions[1] ) : '';
            $thumbnail = '<img ' . $hwstring . ' src="' . $image . '" />';
            $large_img_src = $image;
            break;
    }

    $gal_images .= '<div class="image-wrapper grid-item">' . $thumbnail . '</div>';
}

?>
<div class="cvca-shortcode-images zoo-images<?php echo esc_attr( $css_class ); ?>">
    <?php if ( $atts['title'] != '' ) : ?>
        <h4 class="block-title">
            <?php echo esc_html( $atts['title'] ); ?>
        </h4>
    <?php endif; ?>

    <div class="zoo-images-block">
        <?php if ( !empty( $content ) || $zoo_link_text != '' ) : ?>
            <div class="zoo-images-content">
                <div class="zoo-images-content-wrap">
                    <div class="zoo-images-content-inner">
                        <span class="border"><span></span></span>
                        <?php if ( !empty( $content ) ) : ?>
                            <div class="zoo-images-info">
                                <?php echo rtrim( ltrim(trim($content), "</p>"), "<p>"); ?>
                            </div>
                        <?php endif; ?>
                        <?php if ( $zoo_link_text != '' ) : ?>
                            <div class="button-link">
                                <?php
                                    echo wp_kses( $zoo_start_link, $zoo_allow_tag );
                                    echo esc_html( $zoo_link_text );
                                    echo wp_kses( $zoo_end_link, $zoo_allow_tag );
                                ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <?php if ( $atts['images'] != '' ) : ?>
            <div class="grid grid-gutters">
                <?php echo $gal_images ?>
            </div>
        <?php endif; ?>
    </div>
</div>
