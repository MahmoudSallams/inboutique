<?php
/**
 * Blog Minimal Shortcode
 */
wp_enqueue_style('cvca-style');
$wrapID = 'shortcode_blog_minimal_' . uniqid();
$args = array(
    'post_type' => 'post',
    'posts_per_page' => ($atts['number'] > 0) ? $atts['number'] : get_option('posts_per_page')
);
if ($atts['cat'] != '') {
    if ($atts['parent']) {
        $args['category_name'] = $atts['cat'];
    } else {
        $catid = array();
        foreach (explode(',', $atts['cat']) as $catslug) {
            $catid[] .= get_category_by_slug($catslug)->term_id;
        }
        $args['category__in'] = $catid;
    }
}
if ($atts['post_in'] != '') {
    $args['post__in'] = explode(",", $atts['post_in']);
}
if (!isset($atts['paged'])) {
    $args['paged'] = (get_query_var('paged')) ? get_query_var('paged') : 1;
} else {
    $args['paged'] = $atts['paged'];
}
$the_query = new WP_Query($args);

$wrapClass = $atts['el_class'] . ' cvca-blog-minimal-shortcode';
$class = 'zoo-blog-item layout-item minimal-layout-item col-xs-12';
?>
<div id="<?php echo esc_attr($wrapID); ?>" class="minimal-layout <?php echo esc_attr($wrapClass) ?>">
    <?php if ($atts['title'] != '') { ?>
        <h3 class="title-block"><?php echo esc_html($atts['title']) ?> </h3>
    <?php
    }
    if ($the_query->have_posts()): ?>
        <div class="zoo-container">
        <?php while ($the_query->have_posts()): $the_query->the_post(); ?>
            <article <?php echo post_class( $class ) ?>>
                <div class="zoo-post-inner">
                    <div class="post-info">
                        <span class="post-date"><?php echo esc_html( get_the_date( 'F, j, Y' ) ); ?> </span>
                    </div>

                    <?php the_title( sprintf( '<h3 class="entry-title title-post"><a href="%s" rel="' . esc_html__( 'bookmark', 'cvca' ) . '">', esc_url( get_permalink() ) ), '</a></h3>' ); ?>

                    <?php if ( has_post_thumbnail() ) : ?>
                        <div class="wrap-media">
                            <a href="<?php echo esc_url( get_permalink() ); ?>" title="<?php echo get_the_title() ?>">
                                <?php the_post_thumbnail( 'full' ); ?>
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </article>
        <?php endwhile; ?>
        </div>
        <?php
        $zoo_pag_type = !empty($atts['pagination']) ? $atts['pagination'] : 'standard';

        if ($zoo_pag_type == 'infinity' || $zoo_pag_type == 'ajaxload') {
            $args = array(
               'type'                 => $zoo_pag_type,                             // If not this option, type will set by 'zoo_blog_pagination' customizer controll.
               'delay'                => 500,
               'container_selector'   => '.zoo-container',
               'item_selector'        => '.zoo-blog-item',
               'layout_mode'          => 'vertical',                              // Options: vertical, fitRows,
               'more_text'            => esc_html__('Load More', 'cvca'),     // or use filter hook: zoo_ajax_pagination_more_text
               'no_more_text'         => esc_html__('No More Posts', 'cvca'), // or use filter hook: zoo_ajax_pagination_no_more_text
            );

            zoo_ajax_pagination($the_query, $args);
        } else if ($zoo_pag_type == 'standard') {
            cvca_pagination(3, $the_query, '', '<i class="fa fa-angle-left" aria-hidden="true"></i>', '<i class="fa fa-angle-right" aria-hidden="true"></i>');
        }
        ?>
        <?php
    endif;
    wp_reset_postdata();
    ?>
</div>
