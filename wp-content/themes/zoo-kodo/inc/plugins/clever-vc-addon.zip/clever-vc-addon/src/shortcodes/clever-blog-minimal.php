<?php
/**
 * Add shortcode
 *
 * @internal    Used as a callback. PLEASE DO NOT RECALL THIS METHOD DIRECTLY!
 *
 * @param    array    $atts    Users' defined attributes in shortcode.
 *
 * @return    string    $html    Rendered shortcode content.
 */
function cvca_add_clever_blog_minimal_shortcode( $atts, $content = null )
{
    $atts = shortcode_atts(
        apply_filters('CleverBlogMinimal_shortcode_atts', array(
            'title' => '',
            'cat' => '',
            'parent'=>1,
            'post_in' => '',
            'number' => 8,
            'blog_img_size'=>'medium',
            'pagination' => 'standard',
            'el_class' => ''
        )),
        $atts, 'CleverBlogMinimal'
    );

    $html = cvca_get_shortcode_view( 'blog-minimal', $atts, $content );

    return $html;
}
add_shortcode( 'CleverBlogMinimal', 'cvca_add_clever_blog_minimal_shortcode' );

/**
 * Integrate to Visual Composer
 *
 * @internal    Used as a callback. PLEASE DO NOT RECALL THIS METHOD DIRECTLY!
 */
function cvca_integrate_clever_blog_minimal_shortcode_with_vc()
{
    vc_map(array(
        'name' => esc_html__('Clever Blog Minimal', 'cvca'),
        'base' => 'CleverBlogMinimal',
        'category' => esc_html__('CleverSoft', 'cvca'),
        'icon' => '',
        "params" => array(
            array(
                "type" => "textfield",
                "heading" => esc_html__("Title", 'cvca'),
                "param_name" => "title",
                "admin_label" => true,
                'description' => esc_html__('Enter text used as shortcode title (Note: located above content element)', 'cvca'),
            ),
            array(
                "type" => "cvca_post_categories",
                "heading" => esc_html__("Category IDs", 'cvca'),
                "param_name" => "cat",
                "admin_label" => true,
                'description' => esc_html__('Select category which you want to get post in', 'cvca'),
            ),
            array(
                "type" => "dropdown",
                "heading" => esc_html__("Get posts in children of categories", 'cvca'),
                "param_name" => "parent",
                'std' => 1,
                "value" => array(
                    esc_html__('No', 'cvca' ) => 0,
                    esc_html__('Yes', 'cvca' ) => 1,
                ),
                'description' => esc_html__('Yes, If you want to get post in all children categories', 'cvca'),
            ),
            array(
                "type" => "autocomplete",
                "heading" => esc_html__("Post IDs", 'cvca'),
                "description" => esc_html__("comma separated list of post ids", 'cvca'),
                "param_name" => "post_in",
                'settings' => array(
                    'multiple' => true,
                    'sortable' => true,
                    'min_length' => 0,
                    'no_hide' => true, // In UI after select doesn't hide an select list
                    'groups' => true, // In UI show results grouped by groups
                    'unique_values' => true, // 0In UI show results except selected. NB! You should manually check values in backend
                    'display_inline' => true, // In UI show results inline view
                    'values' => cvca_get_blog_posts_data(),
                ),
            ),
            array(
                'type' => 'cvca_image_size',
                'heading' => esc_html__('Image size', 'cvca'),
                'group'=>esc_html__('Layout','cvca'),
                'std' => 'medium',
                'param_name' => 'blog_img_size',
            ),
            array(
                "type" => "textfield",
                "heading" => esc_html__("Posts Count", 'cvca'),
                "param_name" => "number",
                "value" => '8',
                'description' => esc_html__('Number of post showing', 'cvca'),
            ),
            array(
                'type' => 'dropdown',
                'heading' => esc_html__('Pagination', 'cvca'),
                'param_name' => 'pagination',
                'group' => esc_html__('Layout', 'cvca'),
                'std' => 'standard',
                "value" => array(
                    esc_html__('Standard', 'cvca') => 'standard',
                    esc_html__('Ajaxload', 'cvca') => 'ajaxload',
                    esc_html__('Infinity', 'cvca') => 'infinity',
                ),
            ),
            array(
                'type' => 'textfield',
                'heading' => esc_html__( 'Extra class name', 'cvca' ),
                'param_name' => 'el_class',
                'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'cvca' )
            )
        )
    ));
}
add_action( 'vc_before_init', 'cvca_integrate_clever_blog_minimal_shortcode_with_vc', 10, 0 );
