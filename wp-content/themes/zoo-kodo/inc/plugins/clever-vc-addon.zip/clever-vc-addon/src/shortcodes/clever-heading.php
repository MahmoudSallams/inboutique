<?php

/**
 * Add shortcode
 *
 * @internal    Used as a callback. PLEASE DO NOT RECALL THIS METHOD DIRECTLY!
 *
 * @param    array    $atts    Users' defined attributes in shortcode.
 *
 * @return    string    $html    Rendered shortcode content.
 */
function cvca_add_clever_heading_shortcode( $atts, $content = null )
{
    $atts = shortcode_atts(
        apply_filters('CleverHeading_shortcode_atts', array(
            'style'           => 'normal',
            'number'          => '01',
            'text'            => '',
            'heading_tag'     => 'h3',
            'font_custom'     => '',
            'font_size'       => 36,
            'line_height'     => 36,
            'font_weight'     => 400,
            'letter_spacing'  => '0',
            'text_transform'  => 'none',
            'font_style'      => 'normal',
            'text_color'      => '#252525',
            'text_align'      => 'left',
            'el_class'        => '',
            'css'             => '',
        )),
        $atts, 'CleverBanner'
    );

    $html = cvca_get_shortcode_view( 'heading', $atts, $content );

    return $html;
}
add_shortcode( 'CleverHeading', 'cvca_add_clever_heading_shortcode' );

/**
 * Integrate to Visual Composer
 *
 * @internal    Used as a callback. PLEASE DO NOT RECALL THIS METHOD DIRECTLY!
 */
function cvca_integrate_clever_heading_shortcode_with_vc()
{
    vc_map(
        array(
            'name' => esc_html__('Clever Heading', 'cvca'),
            'base' => 'CleverHeading',
            'icon' => 'fa fa-header',
            'category' => esc_html__('CleverSoft', 'cvca'),
            'description' => esc_html__('Display your heading', 'cvca'),
            'params' => array(
                array(
                    'type'        => 'dropdown',
                    'heading'     => esc_html__( 'Heading style', 'cvca' ),
                    'param_name'  => 'style',
                    'std'         => 'normal',
                    'value'       => array (
                        esc_html__( 'Normal', 'cvca' ) => 'normal',
                        esc_html__( 'Number', 'cvca' ) => 'number',
                    )
                ),

                array(
                    'type'         => 'textfield',
                    'heading'      => esc_html__( 'Number', 'cvca' ),
                    'param_name'   => 'number',
                    'std'          => '01',
                    'dependency'   => array(
                        'element'  => 'style',
                        'value'    => array( 'number' )
                    ),
                ),
                // text
                array(
                    'type'        => 'textarea',
                    'heading'     => esc_html__( 'Text', 'cvca' ),
                    'param_name'  => 'text',
                    'description' => esc_html__('Enter text used as shortcode title (Note: located above content element)', 'cvca'),
                ),

                // heading_tag
                array (
                    'type'       => 'dropdown',
                    'heading'    => esc_html__( 'Element tag', 'cvca' ),
                    'param_name' => 'heading_tag',
                    'std'        => 'h3',
                    'value'      => array (
                        esc_html__( ' h1', 'cvca' ) => 'h1',
                        esc_html__( ' h2', 'cvca' ) => 'h2',
                        esc_html__( ' h3', 'cvca' ) => 'h3',
                        esc_html__( ' h4', 'cvca' ) => 'h4',
                        esc_html__( ' h5', 'cvca' ) => 'h5',
                        esc_html__( ' h6', 'cvca' ) => 'h6',
                        )
                    ),

                // text_align
                array(
                    'type'         => 'dropdown',
                    'heading'      => esc_html__( 'Text Align', 'cvca' ),
                    'param_name'   => 'text_align',
                    'std'          => 'left',
                    'value'        => array(
                        esc_html__( 'Left', 'cvca' )   => 'left',
                        esc_html__( 'Center', 'cvca' ) => 'center',
                        esc_html__( 'Right', 'cvca' ) => 'right',
                        esc_html__( 'Justify', 'cvca' ) => 'justify',

                    ),
                ),

                // font_custom
                array(
                    'type'        => 'checkbox',
                    'param_name'  => 'font_custom',
                    'value'       => array(
                        esc_html__( 'Custom style?', 'cvca' ) => 'yes'
                    ),
                    'std'         => '',
                ),

                array(
                    'type'         => 'textfield',
                    'heading'      => esc_html__( 'Font Size', 'cvca' ),
                    'param_name'   => 'font_size',
                    'std'          => '36',
                    'group'        => esc_html__( 'Heading Options', 'cvca' ),
                    'dependency'   => array(
                        'element'  => 'font_custom',
                        'value'    => array( 'yes' )
                    ),
                ),

                // line_height
                array(
                    'type'         => 'textfield',
                    'heading'      => esc_html__( 'Line height', 'cvca' ),
                    'param_name'   => 'line_height',
                    'std'          => '36',
                    'group'        => esc_attr__( 'Heading Options', 'cvca' ),
                    'dependency'   => array(
                        'element'  => 'font_custom',
                        'value'    => array( 'yes' )
                    ),
                ),

                // text_transform
                array(
                    'type'         => 'dropdown',
                    'heading'      => esc_html__( 'Font Weight', 'cvca' ),
                    'param_name'   => 'font_weight',
                    'std'          => '400',
                    'value'        => array(
                        esc_html__( '100', 'cvca' )  => 100,
                        esc_html__( '200', 'cvca' )  => 200,
                        esc_html__( '300', 'cvca' )  => 300,
                        esc_html__( '400', 'cvca' )  => 400,
                        esc_html__( '500', 'cvca' )  => 500,
                        esc_html__( '600', 'cvca' )  => 600,
                        esc_html__( '700', 'cvca' )  => 700,
                        esc_html__( '900', 'cvca' )  => 900,
                    ),
                    'group'        => esc_attr__( 'Heading Options', 'cvca' ),
                    'dependency'   => array(
                        'element'  => 'font_custom',
                        'value'    => array( 'yes' )
                    ),
                ),

                array(
                    'type'         => 'dropdown',
                    'heading'      => esc_html__( 'Font Style', 'cvca' ),
                    'param_name'   => 'font_style',
                    'std'          => 'normal',
                    'value'        => array(
                        esc_html__( 'Normal', 'cvca' )  => 'normal',
                        esc_html__( 'Italic', 'cvca' )  => 'italic',
                        esc_html__( 'Oblique', 'cvca' )  => 'oblique',
                    ),
                    'group'        => esc_attr__( 'Heading Options', 'cvca' ),
                    'dependency'   => array(
                        'element'  => 'font_custom',
                        'value'    => array( 'yes' )
                    ),
                ),

                // line_height
                array(
                    'type'         => 'textfield',
                    'heading'      => esc_html__( 'Letters spacing', 'cvca' ),
                    'param_name'   => 'letter_spacing',
                    'std'          => '0',
                    'group'        => esc_attr__( 'Heading Options', 'cvca' ),
                    'dependency'   => array(
                        'element'  => 'font_custom',
                        'value'    => array( 'yes' )
                    ),
                ),

                // color
                array(
                    'type'         => 'colorpicker',
                    'heading'      => esc_html__( 'Text Color', 'cvca' ),
                    'param_name'   => 'text_color',
                    'std'          => '#252525',
                    'group'        => esc_attr__( 'Heading Options', 'cvca' ),
                    'dependency'   => array(
                        'element'  => 'font_custom',
                        'value'    => array( 'yes' )
                    ),
                ),

                // text_transform
                array(
                    'type'         => 'dropdown',
                    'heading'      => esc_html__( 'Text Transform', 'cvca' ),
                    'param_name'   => 'text_transform',
                    'std'          => 'none',
                    'value'        => array(
                        esc_html__( 'none', 'cvca' )       => 'none',
                        esc_html__( 'capitalize', 'cvca' ) => 'capitalize',
                        esc_html__( 'uppercase', 'cvca' )  => 'uppercase',
                        esc_html__( 'lowercase', 'cvca' )  => 'lowercase',
                    ),
                    'group'        => esc_attr__( 'Heading Options', 'cvca' ),
                    'dependency'   => array(
                        'element'  => 'font_custom',
                        'value'    => array( 'yes' )
                    ),
                ),

                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Extra class name', 'cvca' ),
                    'param_name' => 'el_class',
                    'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'cvca' )
                ),
                array(
                    'type' => 'css_editor',
                    'heading' => __( 'Css', 'cvca' ),
                    'param_name' => 'css',
                    'group' => __( 'Design options', 'cvca' ),
                ),
            )
        )
    );
}
add_action( 'vc_before_init', 'cvca_integrate_clever_heading_shortcode_with_vc', 10, 0 );
