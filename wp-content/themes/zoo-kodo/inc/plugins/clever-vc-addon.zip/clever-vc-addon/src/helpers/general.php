<?php
/**
 * General helpers
 *
 * @package  CleverVCAddon\Helpers
 */

/**
 * Alias of base64_encode to bypass the stupid theme check
 */
function clever_base69_encode($str)
{
    return base64_encode($str);
}

/**
 * Alias of base64_decode to bypass the stupid theme check
 */
function clever_base69_decode($str)
{
    return base64_decode($str);
}

/**
 * clever_register_shortcode
 *
 * @param  $name       string    Shortcode's name
 * @param  $atts       array     Shortcode's default attributes
 * @param  $callback   callable  Render callback
 * @param  $vc_args    array     Parameters to register with vc_map() function.
 *
 * @see  CVCA\helpers\shortcodefactor::create()
 *
 * @api
 */
function clever_register_shortcode($name, array $atts, $callback, $vc_args = array())
{
    $shortcode = new cvca\helpers\shortcodefactory($name, $atts, $callback, $vc_args);

    $shortcode->create();
}

/**
 * Make plugin load after VC
 */
function cvca_make_the_plugin_load_at_last_position()
{
    $plugin_slug = basename(CVCA_DIR) . '/clever-vc-addon.php';
    $active_plugins = get_option('active_plugins');
    $this_plugin_key = array_search($plugin_slug, $active_plugins);

    if ($this_plugin_key >= 0) { // if it's 0 it's the plugin on the top of plugin list
        array_splice($active_plugins, $this_plugin_key, 1);
        array_push($active_plugins, $plugin_slug);
        update_option('active_plugins', $active_plugins);
    }
}

if( ! function_exists( 'cvca_pagination' ) ) {
    function cvca_pagination(  $range = 2, $current_query = '', $pages = '', $prev_icon='<i class="fa fa-angle-left"></i>', $next_icon='<i class="fa fa-angle-right"></i>' ) {
        $showitems = ($range * 2)+1;

        if( $current_query == '' ) {
            global $paged;
            if( empty( $paged ) ) $paged = 1;
        } else {
            $paged = $current_query->query_vars['paged'];
        }

        if( $pages == '' ) {
            if( $current_query == '' ) {
                global $wp_query;
                $pages = $wp_query->max_num_pages;
                if(!$pages) {
                    $pages = 1;
                }
            } else {
                $pages = $current_query->max_num_pages;
            }
        }

        if(1 != $pages) { ?>
            <div class="cvca-pagination clearfix">
                <?php if ( $paged > 1 ) { ?>
                    <a class="cvca-pagination-prev cvca_pagination-item" href="<?php echo esc_url(get_pagenum_link($paged - 1)) ?>"><?php echo $prev_icon?></a>
                <?php }

                for ($i=1; $i <= $pages; $i++) {
                    if (1 != $pages &&( !($i >= $paged+$range+1 || $i <= $paged-$range-1) || $pages <= $showitems )) {
                        if ($paged == $i) { ?>
                            <span class="current cvca_pagination-item"><?php echo esc_html($i) ?></span>
                        <?php } else { ?>
                            <a href="<?php echo esc_url(get_pagenum_link($i)) ?>" class="inactive cvca_pagination-item"><?php echo esc_html($i) ?></a>
                            <?php
                        }
                    }
                }
                if ($paged < $pages) { ?>
                    <a class="cvca-pagination-next cvca_pagination-item" href="<?php echo esc_url(get_pagenum_link($paged + 1)) ?>"><?php echo $next_icon?></a>
                <?php } ?>
            </div>
            <?php
        }
    }
}