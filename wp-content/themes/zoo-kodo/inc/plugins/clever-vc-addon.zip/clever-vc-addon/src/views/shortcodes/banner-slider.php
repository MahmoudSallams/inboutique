<?php
/**
 * Banner Slider Shortcode
 */
 wp_enqueue_style('slick');
 wp_enqueue_style('cvca-style');
 wp_enqueue_script('slick');
 wp_enqueue_script('cvca-script');

$css_class = '';

$custom_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $atts['css'], ' ' ), 'CleverBannerSlider', $atts );

if ( !empty( $atts['el_class'] ) ) {
    $css_class .= ' ' . $atts['el_class'];
}

if ( !empty( $custom_class ) ) {
    $css_class .= ' ' . $custom_class;
}

$cvca_content = vc_param_group_parse_atts($atts['banners']);

$zoo_allow_tag = array(
    'a' => array(
        'class' => array(),
        'href' => array(),
        'target' => array(),
        'rel' => array(),
        'title' => array()
    ),
    'br' => array()
);

$slick_data_html = '';
$center_padding = '60px';

$columns = ( !empty( $atts['columns'] ) ) ? $atts['columns'] : 3;
$btn_link = ( $atts['btn_link'] == '1' ) ? true : false;
$center_mode = ( $atts['center_mode'] == '1' ) ? true : false;
$show_pag = ( $atts['show_pag'] == '1' ) ? true : false;
$show_nav = ( $atts['show_nav'] == '1' ) ? true : false;

// $slick_data['responsive'] = '[{"breakpoint": 768,"settings":{"slidesToShow": 1}}]';

$slick_data_html = '{"item":"' . $columns . '"';
$slick_data_html .= ',"pagination":"' . $show_pag . '","navigation":"' . $show_nav . '"';

if ( $atts['center_mode'] == '1' ) {
    $css_class .= ' carousel-center';
    if ( !empty($atts['center_padding']) ) {
        $center_padding = $atts['center_padding'];
    }
    $slick_data_html .= ',"center_mode":"' . $atts['center_mode'] . '","center_padding":"' . $center_padding . '"';
}

$slick_data_html .= '}';

?>
<div class="cvca-shortcode-banner-slider cvca-carousel-block<?php echo esc_attr( $css_class ); ?>" data-config='<?php echo esc_attr($slick_data_html); ?>'>
    <?php foreach ( $cvca_content as $cvca_item ) : ?>
        <?php
        $zoo_start_link = $zoo_link_text = $zoo_end_link = '';

        if ( !empty( $cvca_item['link'] ) ) {
            $zoo_link = vc_build_link( $cvca_item['link'] );

            if ( $zoo_link['url'] != '' ) {
                $zoo_start_link = '<a';
                $zoo_start_link .= ' class="banner-media-link"';
                $zoo_start_link .= ' href="' . $zoo_link['url'] . '"';

                if ( $zoo_link['title'] != '' ) {
                    $zoo_start_link .= ' title="' . $zoo_link['title'] . '"';
                }

                if ( $zoo_link['target'] != '' ) {
                    $zoo_start_link .= ' target="' . $zoo_link['target'] . '"';
                }

                 if ( $zoo_link['rel'] != '' ) {
                    $zoo_start_link .= ' rel="' . $zoo_link['rel'] . '"';
                }

                $zoo_start_link .= '>';
            }

            $zoo_link_text = ( $zoo_link['title'] != '' ) ? $zoo_link['title'] : '';

            if ( $zoo_link['url'] != '' ) {
                $zoo_end_link = '</a>';
            }
        }
        ?>

        <div class="banner-item">
            <div class="banner-item-inner">
                <?php if ( $cvca_item['image'] != '' ) { ?>
                    <div class="banner-media<?php echo ( empty( $cvca_item['link'] ) ) ? ' banner-media-link' : ''; ?>">
                        <?php if ( $cvca_item['image'] != '' ) {
                            echo wp_kses( $zoo_start_link, $zoo_allow_tag );
                            echo wp_get_attachment_image( $cvca_item['image'], 'full' );
                            echo wp_kses( $zoo_end_link, $zoo_allow_tag );
                        } ?>
                    </div>
                <?php } ?>
                <?php if ( isset($cvca_item['title']) != '' || isset($cvca_item['description']) != '' || ( $btn_link && $zoo_link_text != '' ) ) : ?>
                    <div class="banner-content">
                        <div class="banner-content-inner">
                            <?php if ( $cvca_item['title'] != '' ) : ?>
                                <h4 class="banner-title">
                                    <?php echo wp_kses( $zoo_start_link, $zoo_allow_tag ); ?>
                                    <?php if ( isset($cvca_item['subtitle']) != '' ) : ?>
                                        <span class="subtitle"><?php echo esc_html( $cvca_item['subtitle'] ); ?></span>
                                    <?php endif; ?>
                                    <?php
                                    echo esc_html( $cvca_item['title'] );
                                    echo wp_kses( $zoo_end_link, $zoo_allow_tag );
                                    ?>
                                </h4>
                            <?php endif; ?>

                            <?php if ( isset($cvca_item['description']) != '' ) : ?>
                                <div class="banner-description">
                                    <?php echo esc_html( $cvca_item['description'] ); ?>
                                </div>
                            <?php endif; ?>

                            <?php if ( $btn_link && $zoo_link_text != '' ) : ?>
                                <div class="banner-readmore">
                                    <?php
                                        echo wp_kses( $zoo_start_link, $zoo_allow_tag );
                                        echo esc_html( $zoo_link_text );
                                        echo wp_kses( $zoo_end_link, $zoo_allow_tag );
                                    ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>

    <?php endforeach; ?>
</div>
