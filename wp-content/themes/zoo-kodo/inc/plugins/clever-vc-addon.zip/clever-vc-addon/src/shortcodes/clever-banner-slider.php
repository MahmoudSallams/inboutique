<?php

/**
 * Add shortcode
 *
 * @internal    Used as a callback. PLEASE DO NOT RECALL THIS METHOD DIRECTLY!
 *
 * @param    array    $atts    Users' defined attributes in shortcode.
 *
 * @return    string    $html    Rendered shortcode content.
 */
function cvca_add_clever_banner_slider_shortcode( $atts, $content = null )
{
    $atts = shortcode_atts(
        apply_filters('CleverBannerSlider_shortcode_atts', array(
            'banners'       => '',
            'btn_link'      => '0',
            'columns'       => '3',
            'center_mode'   => '',
            'center_padding'   => '',
            'show_pag'      => '',
            'show_nav'      => '1',
            'el_class'      => '',
            'css'           => ''
        )),
        $atts, 'CleverBannerSlider'
    );

    $html = cvca_get_shortcode_view( 'banner-slider', $atts, $content );

    return $html;
}
add_shortcode( 'CleverBannerSlider', 'cvca_add_clever_banner_slider_shortcode' );

/**
 * Integrate to Visual Composer
 *
 * @internal    Used as a callback. PLEASE DO NOT RECALL THIS METHOD DIRECTLY!
 */
function cvca_integrate_clever_banner_slider_shortcode_with_vc()
{
    vc_map(
        array(
            'name' => esc_html__('Clever Banner Slider', 'cvca'),
            'base' => 'CleverBannerSlider',
            'icon' => '',
            'category' => esc_html__('CleverSoft', 'cvca'),
            'description' => esc_html__('Display your banner image', 'cvca'),
            'params' => array(
                array(
                    'type' => 'param_group',
                    'heading' => esc_html__('Banners', 'cvca'),
                    'value' => '',
                    'param_name' => 'banners',
                    'description' => esc_html__('Click to show more options, and starting add content.', 'cvca'),
                    // Note params is mapped inside param-group:
                    'params' => array(
                        array(
                            'type' => 'attach_image',
                            'heading' => esc_html__( 'Image', 'cvca' ),
                            'param_name' => 'image',
                            'description' => esc_html__( 'Image of banner', 'cvca' )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Title', 'cvca' ),
                            'param_name' => 'title',
                            'description' => esc_html__('', 'cvca'),
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Sub Title', 'cvca' ),
                            'param_name' => 'subtitle',
                            'description' => esc_html__('', 'cvca'),
                        ),
                        array(
                            'type' => 'textarea',
                            'heading' => esc_html__('Description', 'cvca' ),
                            'param_name' => 'description',
                            'description' => esc_html__('', 'cvca'),
                        ),
                        array(
                            'type' => 'vc_link',
                            'heading' => esc_html__('Link', 'cvca'),
                            'value' => '#',
                            'param_name' => 'link',
                        ),
                    )
                ),
                array(
                    'type' => 'checkbox',
                    'heading' => esc_html__('Show button link', 'cvca'),
                    'param_name' => 'btn_link',
                    'std' => '0',
                    'value' => array(esc_html__('Yes', 'cvca') => '1'),
                ),
                array(
                    "type" => "textfield",
                    "heading" => esc_html__("Slides To Show", 'cvca'),
                    "param_name" => "columns",
                    "value" => '3',
                    'description' => esc_html__('Display photos with the number of column', 'cvca'),
                ),
                array(
                    'type' => 'checkbox',
                    'heading' => esc_html__('Center Mode', 'cvca'),
                    'param_name' => 'center_mode',
                    'std' => '',
                    'value' => array(esc_html__('Yes', 'cvca') => '1'),
                ),
                array(
                    "type" => "textfield",
                    "heading" => esc_html__("Center Padding", 'cvca'),
                    "param_name" => "center_padding",
                    "value" => '',
                    'dependency' => array('element' => 'center_mode', 'value' => array('1')),
                    'description' => esc_html__('Padding of items in carousel', 'cvca'),
                ),
                array(
                    'type' => 'checkbox',
                    'heading' => esc_html__('Show carousel pagination', 'cvca'),
                    'param_name' => 'show_pag',
                    'std' => '',
                    'value' => array(esc_html__('Yes', 'cvca') => '1'),
                ),
                array(
                    'type' => 'checkbox',
                    'heading' => esc_html__('Show carousel navigation', 'cvca'),
                    'param_name' => 'show_nav',
                    'std' => '1',
                    'value' => array(esc_html__('Yes', 'cvca') => '1'),
                ),
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Extra class name', 'cvca' ),
                    'param_name' => 'el_class',
                    'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'cvca' )
                ),
                array(
                    'type' => 'css_editor',
                    'heading' => __( 'Css', 'cvca' ),
                    'param_name' => 'css',
                    'group' => __( 'Design options', 'cvca' ),
                ),
            )
        )
    );
}
add_action( 'vc_before_init', 'cvca_integrate_clever_banner_slider_shortcode_with_vc', 10, 0 );
